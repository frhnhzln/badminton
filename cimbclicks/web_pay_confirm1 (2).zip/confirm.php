<?php 
session_start();
include("connection.php");
include "dbconn.php";



if(isset($_SESSION['deposit'])){
	$username = $_SESSION['username'];
	$balance = $_SESSION['deposit'];
	$buaya = $_SESSION["buaya"];
	//$business = $_SESSION['business'];
	//$order_id = $_SESSION['order_id'];
	//$trx_id = $_SESSION['neworderid'];
	//$cust_email = $_SESSION['cust_email'];
	//$amount = $_SESSION['pay_amount'];
	$return_url = $_SESSION['return_url'];
	$cancel_url = $_SESSION['return_url'];
	$user_id = $_SESSION['user'];
	$pay_date=date("Y-m-d H:i:s");
    $uq="UPDATE bookings SET booking_payment='paid' WHERE booking_id= '$buaya'";
    $run_update = mysqli_query($con, $uq);

   // $insert_trx_q="INSERT INTO payments(payment_id,student_id,total_rate,payment_time) VALUES('$trx_id',$order_id,$amount,'$pay_date')";
   // $run_trx=mysqli_query($con, $insert_trx_q);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Confirmation</title>
</head>

<body>

Username: <?php echo $username;?><br />
Balance: RM <?php echo $balance ?><br />

<form action="<?php echo $return_url;?>" method="post">
<input type="hidden" name="trx_id" value="<?php echo $trx_id?>" />
<input type="hidden" name="order_id" value="<?php echo $order_id;?>" />

<input type="hidden" name="pay_date" value="<?php echo $pay_date;?>" />
<input type="submit" name="payment_success" value="Ok" />

</form>
</body>
</html>