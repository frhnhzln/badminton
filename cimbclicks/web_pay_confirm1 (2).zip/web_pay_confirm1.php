<?php
session_start();
include "connection.php";
include "dbconn.php";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CimbClicks</title>
</head>

<body>

<?php

$buaya = $_SESSION["buaya"];
echo $buaya;
$sql = ("SELECT * FROM bookings WHERE booking_id = '$buaya'");

$result = mysqli_query($conn, $sql);
$num_rows = mysqli_num_rows($result);
if($num_rows > 0){
	   while($row = mysqli_fetch_assoc($result)){


//$booking_fee = $result ["booking_fee"];
$booking_id = $_SESSION['booking_id'];
$email = $_SESSION['email'];
//$order_id = $_SESSION['order_id'];
//$business = $_SESSION['business'];
//$order_id = $_SESSION['neworderid'];
//$cust_email = $_SESSION['cust_email'];
$booking_fee =  $row["booking_fee"];
$_SESSION['return_url']="../confirmbooking.php?booking_id=$buaya";
$user_id = $_SESSION['user'];//ok
$username = $_SESSION['username'];//ok
$deposit = $_SESSION['deposit'];//ok
$cancel_url = $_SESSION['return_url'];


    }
    }

?><br />
<br />

<h2>Username: <?php echo $username;?></h2>
<h3>Account Balance: RM <?php echo $deposit;?></h3><br />
<br />
<h3>Payment For: Football Field Reservation</h3>
<table>
<tr><th colspan="3" align="left">Booking ID: <?php echo $booking_id;?></th></tr>
<tr><td>Email:</td><td>:</td><td><?php echo $email;?></td></tr>
<tr><td>Total:</td><td>:</td><td>RM <?php echo $booking_fee;?></td></tr>
<tr><td><form action="" method="get"><button type="submit" name="confirm">Bayar</button></td><td></td><td><button onClick="window.open('<?php echo $cancel_url;?>','_self'); return false;">Batal</button></td></tr>

</table>

</body>
</html>
<?php

if(isset($_GET['confirm'])){

	$balance = $deposit-$booking_fee;
	$balance_update = mysqli_query($conn, "UPDATE user SET user_deposit='$balance' where user_id='$user_id'");
	if($balance_update){

		$_SESSION['deposit'] = $balance;

	echo "<script>alert('Pembayaran Berjaya')</script>";
	echo "<script>window.open('confirm.php','_self')</script>";
	}

}

?>
