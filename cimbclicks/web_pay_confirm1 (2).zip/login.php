<?php
session_start();
include "connection.php";
include "dbconn.php";
if(isset($_SESSION["payment"]))
{
    $payment =  $_SESSION["payment"];
    $booking_id = $_SESSION["booking"];
    $student_id = $_SESSION["student_id"];
    $insertOrder = $db_handle->insertQuery("INSERT  INTO orders (customer_id, status, total_price) "
            . "VALUES ('$customer_id', 'unpaid', '$total_price') ");
    if($insertOrder)
    {
        //echo "insert orders success<br/>";
        //$last_id = $conn->insert_id;
        $last_id = $db_handle->getLastID();
                echo "Order ID = ".$last_id;
        $_SESSION["neworderid"] = $last_id;
    }
     foreach ($_SESSION["cart_item"] as $item){
		
         $inserOrderDetailsQuery = "INSERT INTO ordersdetails (order_id, product_id, price, quantity, customer_id) "
                 . "VALUES ('$last_id', '" . $item["code"] . "','" . $item["price"] . "','" . $item["quantity"] ."' ,'$customer_id')";
				//$item["name"]; $item["code"]; ;
				//;
				//$item_total += ($item["price"]*$item["quantity"]);
                                
                                $insertOrdersDetails = $db_handle->insertQuery($inserOrderDetailsQuery);
                                if($insertOrdersDetails)
    {
       
        //$last_id = $db_handle->getLastID();
         //       echo "<BR/>Order Details ID = ".$last_id;
    }
		}
    
}

$booking_id=0;
if(isset($_GET["action"])=='submit' && isset($_GET["booking_id"]))
{
    $booking_id=$_GET["booking_id"];
    $_SESSION["buaya"] = $booking_id;
}
else{
    echo "Invalid Request"; die;
}
		



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CimbClicks</title>
</head>

<body>

    <?php //echo $_SESSION['payment'];
    //echo $_SERVER["REQUEST_URI"];
    echo "<br/>";
    // qecho $_SESSION["return_url"];
	
    ?>
<br />
<br />
<br />
<p align="center"><img src="gambarclick.png"></p>
<div align="center">

<form action="logindb.php" method="post">
<input type="text" name="username" />
<input type="password" name="pass" />
<input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
<input type="submit" name="login" value="Login">
<button onClick="window.open('<?php //echo $cancel;?>','_self'); return false;">Cancel</button>
</form>

</div>
</body></html>
